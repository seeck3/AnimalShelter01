const petController = require('./pet.controller');

module.exports = {

  petController,
};

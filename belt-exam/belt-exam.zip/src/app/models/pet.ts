export class Pet {
  _id: string;
  name: string;
  type: string;
  description: string;
  skill01: string;
  skill02: string;
  skill03: string;
}
